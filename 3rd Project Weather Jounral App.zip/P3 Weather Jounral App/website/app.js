/* Global Variables */
const URL = "http://api.openweathermap.org/data/2.5/forecast?zip="
const myApiKey = "&appid=8a64473dd2a710a2e8e0604f7f707b65";
//TODO need to update Elements
let d = new Date();
let newDate = d.getMonth()+'.'+ d.getDate()+'.'+ d.getFullYear();
let date = document.getElementById('date');
let temp = document.getElementById('temp');
let moodPost = document.getElementById('content');


//html Elements
const Zip = document.getElementById('zip').value;
const mood = document.getElementById('feelings').value;




document.getElementById('generate').addEventListener('click', postWeather);

function postWeather(){
    watherFromApi(URL, Zip, myApiKey).then( data => {
        console.log('asdfhkja', data);

        postData("http://localhost:8000/add", {
            city: data.city.name, 
            date: newDate,
            temperature: data.list[0].main.temp, 
            mood: mood,
        })
        printToUI(); 
            
    })
};


//get data from weather API
const watherFromApi = async ( url, zip, apiKey ) => {
    let respond = await fetch(url + zip + apiKey);
    try{
        let weatherData = await respond.json();
        console.log('got data:', weatherData);
        return weatherData;
    } catch(err){
        console.log("error detected while getting weather", err);
    }
}


//ui update
const printToUI = async () => {
    
    const request = await fetch("http://localhost:8000/all");

    try{
        const Data = await request.json();
        date.innerHTML = `City and Date is : ${Data.city} --> ${Data.date}`;
        temp.innerHTML += `Temperature is : ${Data.temperature}`;
        moodPost.innerHTML += `I am feeling : ${Data.mood}`;
        console.log('updated Data:', Data);

    } catch(err) {
        console.log("Error", err);
    }
};


//post data function right from the lessons 
const postData = async ( url = '', data = {} ) => {

    const response = await fetch(url, {
        method: 'POST', 
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json',
        },    
        body: JSON.stringify(data), 
    });

    try {
        const newData = await response.json();
        if(newData.ok){
            return newData;
        } else {
            console.warn('error');
        }
        
    }catch(error){
        console.warn('error',error);
    }
};



